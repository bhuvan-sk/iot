import { useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { TopBar } from './components/TopBar';
import { Dashboard } from './pages/Dashboard';
import { getEsp32Status } from './services/api';
import type { ESP32Status } from './types';

const PlaceholderPage = ({ title }: { title: string }) => (
  <div className="flex-1 flex items-center justify-center">
    <div className="text-center">
      <h2 className="text-2xl font-bold text-slate-300 mb-2">{title}</h2>
      <p className="text-slate-500">This section is under construction.</p>
    </div>
  </div>
);

function App() {
  const [espStatus, setEspStatus] = useState<ESP32Status | null>(null);

  useEffect(() => {
    const fetchStatus = async () => {
      try {
        const status = await getEsp32Status();
        setEspStatus(status);
      } catch (error) {
        console.error('Failed to fetch ESP32 status', error);
        setEspStatus({ status: 'Offline', ipAddress: '', wifiSignal: 0, uptime: '', firmware: '', lastHeartbeat: '' });
      }
    };
    
    fetchStatus();
    const interval = setInterval(fetchStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <BrowserRouter>
      <div className="flex h-screen bg-slate-950 text-slate-200 overflow-hidden font-sans">
        <Sidebar esp32Status={espStatus} />
        
        <div className="flex-1 flex flex-col h-full overflow-y-auto">
          <TopBar esp32Status={espStatus} />
          
          <main className="flex-1 text-white">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/sensors" element={<PlaceholderPage title="Sensors" />} />
              <Route path="/devices" element={<PlaceholderPage title="Devices" />} />
              <Route path="/automations" element={<PlaceholderPage title="Automations" />} />
              <Route path="/alerts" element={<PlaceholderPage title="Alerts" />} />
              <Route path="/settings" element={<PlaceholderPage title="Settings" />} />
            </Routes>
          </main>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
