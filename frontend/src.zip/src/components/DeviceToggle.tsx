import React, { useState } from 'react';
import type { Device } from '../types';
import { toggleDevice } from '../services/api';
import { clsx } from 'clsx';
import { Power, Lightbulb } from 'lucide-react';

export const DeviceToggle: React.FC<{ device: Device; onToggle: () => void }> = ({ device, onToggle }) => {
  const [loading, setLoading] = useState(false);
  const isOn = device.state === 'ON';

  const handleToggle = async () => {
    setLoading(true);
    try {
      await toggleDevice(device.id);
      onToggle();
    } catch (error) {
      console.error('Failed to toggle device', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-5 flex items-center justify-between hover:bg-slate-800/60 transition-colors backdrop-blur-sm">
      <div className="flex items-center gap-4">
        <div className={clsx(
          "w-12 h-12 rounded-xl flex items-center justify-center transition-colors",
          isOn ? "bg-amber-500/20 text-amber-400" : "bg-slate-800 text-slate-500"
        )}>
          <Lightbulb className={clsx("w-6 h-6", isOn && "animate-pulse")} />
        </div>
        <div>
          <h4 className="text-white font-medium">{device.name}</h4>
          <p className="text-xs text-slate-400">GPIO {device.gpio}</p>
        </div>
      </div>

      <button
        onClick={handleToggle}
        disabled={loading}
        className={clsx(
          "relative w-14 h-8 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 focus:ring-offset-slate-900",
          isOn ? "bg-emerald-500" : "bg-slate-700",
          loading && "opacity-50 cursor-not-allowed"
        )}
      >
        <div className={clsx(
          "absolute top-1 w-6 h-6 rounded-full bg-white transition-transform flex items-center justify-center",
          isOn ? "left-7" : "left-1"
        )}>
          <Power className={clsx("w-3 h-3", isOn ? "text-emerald-500" : "text-slate-400")} />
        </div>
      </button>
    </div>
  );
};
