import { useEffect, useState } from 'react';
import { EnvironmentGraph } from '../components/EnvironmentGraph';
import { SensorCard } from '../components/SensorCard';
import { DeviceToggle } from '../components/DeviceToggle';
import { getSensors, getDevices, getAutomations, getAlerts } from '../services/api';
import type { Sensor, Device, Automation, Alert } from '../types';
import { AlertTriangle, Info, Zap } from 'lucide-react';
import { clsx } from 'clsx';

export const Dashboard = () => {
  const [sensors, setSensors] = useState<Sensor[]>([]);
  const [devices, setDevices] = useState<Device[]>([]);
  const [automations, setAutomations] = useState<Automation[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);

  const fetchData = async () => {
    try {
      const [fetchedSensors, fetchedDevices, fetchedAutomations, fetchedAlerts] = await Promise.all([
        getSensors(),
        getDevices(),
        getAutomations(),
        getAlerts()
      ]);
      setSensors(fetchedSensors);
      setDevices(fetchedDevices);
      setAutomations(fetchedAutomations);
      setAlerts(fetchedAlerts);
    } catch (error) {
      console.error("Error fetching dashboard data", error);
    }
  };

  useEffect(() => {
    console.log("Dashboard mounted");
    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  console.log("Rendering Dashboard with sensors:", sensors);

  const avgTemp = sensors.length ? (sensors.reduce((acc, s) => acc + (s.lastReading?.temperature || 0), 0) / sensors.length).toFixed(1) : '--';
  const avgHum = sensors.length ? (sensors.reduce((acc, s) => acc + (s.lastReading?.humidity || 0), 0) / sensors.length).toFixed(0) : '--';
  const activeLights = devices.filter(d => d.state === 'ON').length;

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 backdrop-blur-sm">
          <p className="text-slate-400 text-sm font-medium mb-1">Average Temp</p>
          <div className="flex items-end gap-1">
            <span className="text-3xl font-bold text-white">{avgTemp}</span>
            <span className="text-slate-400 mb-1">°C</span>
          </div>
        </div>
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 backdrop-blur-sm">
          <p className="text-slate-400 text-sm font-medium mb-1">Average Humidity</p>
          <div className="flex items-end gap-1">
            <span className="text-3xl font-bold text-white">{avgHum}</span>
            <span className="text-slate-400 mb-1">%</span>
          </div>
        </div>
        <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 backdrop-blur-sm">
          <p className="text-slate-400 text-sm font-medium mb-1">Active Devices</p>
          <div className="flex items-end gap-1">
            <span className="text-3xl font-bold text-emerald-400">{activeLights}</span>
            <span className="text-slate-400 mb-1">/ {devices.length} ON</span>
          </div>
        </div>
        <div className="bg-gradient-to-br from-emerald-900/40 to-slate-800/40 border border-emerald-500/20 rounded-2xl p-6 backdrop-blur-sm">
          <p className="text-emerald-400/80 text-sm font-medium mb-1">System Status</p>
          <div className="flex items-end gap-2">
            <span className="text-3xl font-bold text-white">Healthy</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* Main Graph */}
          <div className="h-[400px]">
            <EnvironmentGraph sensors={sensors} />
          </div>

          {/* Sensors List */}
          <div>
            <h3 className="text-xl font-bold text-white mb-4">Sensors</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {sensors.map(sensor => (
                <SensorCard key={sensor.id} sensor={sensor} />
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-8">
          {/* Devices List */}
          <div className="bg-slate-800/20 border border-slate-700/30 rounded-2xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              Lights & Devices
            </h3>
            <div className="space-y-4">
              {devices.map(device => (
                <DeviceToggle key={device.id} device={device} onToggle={fetchData} />
              ))}
            </div>
          </div>

          {/* Automations */}
          <div className="bg-slate-800/20 border border-slate-700/30 rounded-2xl p-6">
             <h3 className="text-lg font-bold text-white mb-4">Automations</h3>
             <div className="space-y-3">
               {automations.map(auto => (
                 <div key={auto.id} className="flex items-center justify-between p-3 bg-slate-900/50 rounded-xl border border-slate-800">
                    <div>
                      <p className="text-sm font-medium text-slate-200">{auto.name}</p>
                      <p className="text-xs text-slate-400">{auto.trigger} → {auto.action}</p>
                    </div>
                    <div className={clsx(
                      "px-2 py-1 rounded text-[10px] font-bold tracking-wider",
                      auto.enabled ? "bg-emerald-500/20 text-emerald-400" : "bg-slate-700 text-slate-400"
                    )}>
                      {auto.enabled ? 'ON' : 'OFF'}
                    </div>
                 </div>
               ))}
             </div>
          </div>

          {/* Alerts */}
          {alerts.length > 0 && (
            <div className="bg-slate-800/20 border border-slate-700/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
                Alerts
              </h3>
              <div className="space-y-3">
                {alerts.map(alert => (
                  <div key={alert.id} className={clsx(
                    "flex gap-3 p-3 rounded-xl border",
                    alert.type === 'warning' ? "bg-amber-500/10 border-amber-500/20" : "bg-blue-500/10 border-blue-500/20"
                  )}>
                    {alert.type === 'warning' ? <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" /> : <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />}
                    <div>
                      <p className={clsx("text-sm font-medium", alert.type === 'warning' ? "text-amber-200" : "text-blue-200")}>{alert.message}</p>
                      <p className="text-xs text-slate-400 mt-1">{new Date(alert.timestamp).toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
