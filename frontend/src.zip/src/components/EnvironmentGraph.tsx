import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import type { Sensor } from '../types';
import { getSensorHistory } from '../services/api';

interface EnvironmentGraphProps {
  sensors: Sensor[];
}

export const EnvironmentGraph: React.FC<EnvironmentGraphProps> = ({ sensors }) => {
  const [data, setData] = useState<any[]>([]);
  const [view, setView] = useState<'Temperature' | 'Humidity' | 'Both'>('Both');

  useEffect(() => {
    const fetchHistory = async () => {
      // In a real app we'd fetch for selected sensors, here we just fetch for the first one (e.g., Living Room) for demo
      if (sensors.length > 0) {
        try {
           const history = await getSensorHistory(sensors[0].id);
           const formatted = history.map(h => ({
             time: new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
             temperature: h.temperature,
             humidity: h.humidity
           }));
           setData(formatted);
        } catch (e) {
           console.error(e);
        }
      }
    };
    
    fetchHistory();
    const interval = setInterval(fetchHistory, 5000);
    return () => clearInterval(interval);
  }, [sensors]);

  return (
    <div className="bg-slate-800/40 border border-slate-700/50 rounded-2xl p-6 backdrop-blur-sm h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-lg font-semibold text-white">Environment Trends</h3>
        <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-700">
          {(['Temperature', 'Humidity', 'Both'] as const).map(option => (
            <button
              key={option}
              onClick={() => setView(option)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                view === option ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="colorHum" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
            <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} tickMargin={10} />
            <YAxis yAxisId="left" stroke="#94a3b8" fontSize={12} tickFormatter={(val) => `${val}°C`} hide={view === 'Humidity'} />
            <YAxis yAxisId="right" orientation="right" stroke="#94a3b8" fontSize={12} tickFormatter={(val) => `${val}%`} hide={view === 'Temperature'} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#1e293b', borderColor: '#334155', borderRadius: '0.5rem', color: '#f8fafc' }}
              itemStyle={{ color: '#f8fafc' }}
            />
            <Legend />
            {(view === 'Temperature' || view === 'Both') && (
              <Area yAxisId="left" type="monotone" dataKey="temperature" name="Temperature" stroke="#f43f5e" strokeWidth={2} fillOpacity={1} fill="url(#colorTemp)" />
            )}
            {(view === 'Humidity' || view === 'Both') && (
              <Area yAxisId="right" type="monotone" dataKey="humidity" name="Humidity" stroke="#06b6d4" strokeWidth={2} fillOpacity={1} fill="url(#colorHum)" />
            )}
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};
